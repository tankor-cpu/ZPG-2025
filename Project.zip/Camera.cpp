#include "Camera.h"

Camera::Camera(const glm::vec3& eye, const glm::vec3& center, const glm::vec3& up) : eye(eye), center(center), up(up)
{}

glm::mat4 Camera::getViewMatrix() const
{
	return glm::lookAt(eye, center, up);
}

glm::mat4 Camera::getProjectionMatix(float width, float height) const
{
	return glm::perspective(glm::radians(45.0f), width/height, 0.1f, 100.0f);
}

void Camera::moveForward(float distance)
{
	glm::vec3 direction = glm::normalize(center - eye);
	eye += direction * distance;
	center += direction * distance;
}

void Camera::moveRight(float distance)
{
	glm::vec3 right = glm::normalize(glm::cross(center - eye, up));
	eye += right * distance;
	center += right * distance;
}

void Camera::moveLeft(float distance)
{
	glm::vec3 right = glm::normalize(glm::cross(center - eye, up));
	eye -= right * distance;
	center -= right * distance;
}

void Camera::moveBackward(float distance)
{
	glm::vec3 direction = glm::normalize(center - eye);
	eye -= direction * distance;
	center -= direction * distance;

}
