#pragma once
//Include GLM  
#include <glm/vec3.hpp> // glm::vec3
#include <glm/vec4.hpp> // glm::vec4
#include <glm/mat4x4.hpp> // glm::mat4
#include <glm/gtc/matrix_transform.hpp> // glm::translate, glm::rotate, glm::scale, glm::perspective
#include <glm/gtc/type_ptr.hpp> // glm::value_ptr

class Camera
{
public:
	Camera(const glm::vec3& eye, const glm::vec3& center, const glm::vec3& up);

	glm::mat4 getViewMatrix() const;
	glm::mat4 getProjectionMatix(float width, float height) const;

	void moveForward(float distance);
	void moveRight(float distance);
	void moveLeft(float distance);
	void moveBackward(float distance);

	glm::vec3 getEye() const { return eye; }
	glm::vec3 getCenter() const { return center; }
	void setCenter(const glm::vec3& c) { center = c; }
private:
	glm::vec3 eye;
	glm::vec3 center;
	glm::vec3 up;
};

