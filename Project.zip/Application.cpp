#include "Application.h"
#include "CombinedTransformation.h"
#include "Translation.h"
#include "Rotation.h"
#include "Scale.h"
#include "Camera.h"

#include "Models/sphere.h"
#include "Models/plain.h"
#include "Models/gift.h"
#include "Models/bushes.h"
#include "Models/suzi_flat.h"
#include "Models/suzi_smooth.h"
#include "Models/tree.h"

Application::Application(int width, int height, const char* title)
{
	this->window = nullptr;
	this->width = width;
	this->height = height;
	if (title != nullptr)
		this->title = title;
	else
		this->title = "ZPG";
}
Application::~Application()
{
	cleanup();
}

void Application::run()
{
	if (!init()) {
		fprintf(stderr, "Failed to initialize application\n");
		return;
	}
	
	mainLoop();
	cleanup();
}


void Application::error_callback(int error, const char* description)
{
	std::fputs(description, stderr);
}

bool Application::initGLFW_()
{
	if (!glfwInit()) {
		fprintf(stderr, "ERROR: could not start GLFW3\n");
		return false;
	}
	glfwSetErrorCallback(error_callback);

	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE); 
	return true;
}

bool Application::initGLEW_()
{
	glewExperimental = GL_TRUE;
	if (glewInit() != GLEW_OK) {
		fprintf(stderr, "Failed to initialize GLEW\n");
		return false;
	}
	return true;
}

bool Application::createWindow_()
{
	window = glfwCreateWindow(width, height, title.c_str(), NULL, NULL);
	if (!window) {
		glfwTerminate();
		return false;
	}
	glfwMakeContextCurrent(window);
	glfwSwapInterval(1);
	return true;
}

bool Application::createShaders_()
{
	Shader vertex(GL_VERTEX_SHADER);
	Shader fragment(GL_FRAGMENT_SHADER);

	if (!vertex.compileFromFile("shaders/default.vert")) return false;
	if (!fragment.compileFromFile("shaders/default.frag")) return false;

	shaderProgram.attachShader(vertex);
	shaderProgram.attachShader(fragment);

	if (!shaderProgram.link()) return false;
	return true;
}

bool Application::createModels_()
{
	std::vector<float> pts2 = {
	   -0.6f, -0.4f, 0.0f,   1.0f, 0.0f, 0.0f,
		0.6f, -0.4f, 0.0f,   0.0f, 1.0f, 0.0f,
		0.0f,  0.6f, 0.0f,   0.0f, 0.0f, 1.0f

	};
	model2.setVertices(pts2, 6,0,3);

	std::vector<float> sphereData(sphere, sphere + 17280);
	sphereModel.setVertices(sphereData,9,0,6);

	std::vector<float> plainVerts(plain, plain + 36);
	modelPlain.setVertices(plainVerts, 9, 0, 6);

	std::vector<float> giftVerts(gift, gift + sizeof(gift) / sizeof(float));
	modelGift.setVertices(giftVerts, 9, 0, 6);

	std::vector<float> bushesVerts(bushes, bushes + sizeof(bushes) / sizeof(float));
	modelBushes.setVertices(bushesVerts, 9, 0, 6);

	std::vector<float> suziFlatVerts(suziFlat, suziFlat + 17424);
	modelSuziFlat.setVertices(suziFlatVerts, 9, 0, 6);

	std::vector<float> suziSmoothVerts(suziSmooth, suziSmooth + 17424);
	modelSuziSmooth.setVertices(suziSmoothVerts, 9, 0, 6);

	std::vector<float> treeVerts(tree, tree + sizeof(tree)/ sizeof(float));
	modelTree.setVertices(treeVerts, 9, 0, 6);


	return true;
}

bool Application::init()
{
	if (!initGLFW_()) {
		fprintf(stderr, "Failed to initialize GLFW\n");
		return false;
	}
	if (!createWindow_()) {
		fprintf(stderr, "Failed to create window\n");
		return false;
	}
	if (!initGLEW_()) {
		fprintf(stderr, "Failed to initialize GLEW\n");
		return false;
	}
	if (!createShaders_()) {
		fprintf(stderr, "Failed to create shaders\n");
		return false;
	}
	if (!createModels_()) {
		fprintf(stderr, "Failed to create models\n");
		return false;
	}

	auto t1 = new CombinedTransformation();
	t1->addTransformation(new Rotation(0.0f, 0.0f, 1.0f, 0.0f));
	t1->addTransformation(new Translation(glm::vec3(-0.5f, 0.0f, 0.0f)));

	auto staticRotation = new Rotation(0.0f, 0.0f, 0.0f, 1.0f);
	auto t2 = new CombinedTransformation();
	t2->addTransformation(staticRotation);
	t2->addTransformation(new Translation(glm::vec3(0.0f, 0.0f, 0.0f)));

	
	
	SceneObject* object2 = new SceneObject(
		&model2,
		&shaderProgram,
		t2
	);

	Scene* scene1 = new Scene();
	std::vector<glm::vec3> positions = {
		glm::vec3(0.7f, 0.0f, 0.0f),  // +X
		glm::vec3(-0.7f, 0.0f, 0.0f), // -X
		glm::vec3(0.0f, 0.7f, 0.0f),  // +Y
		glm::vec3(0.0f, -0.7f, 0.0f)  // -Y
	};
	for (auto& pos : positions) {
		auto transform = new CombinedTransformation();
		transform->addTransformation(new Translation(pos));
		transform->addTransformation(new Scale(glm::vec3(0.4f)));

		SceneObject* sphereObject = new SceneObject(
			&sphereModel,
			&shaderProgram,
			transform
		);

		scene1->addObject(sphereObject);
	}

	Scene* scene2 = new Scene();
	scene2->addObject(object2);


	Scene* scene3 = new Scene();
	std::vector<Model*> models = {
		&sphereModel, &modelPlain, &modelGift,
		&modelBushes, &modelSuziFlat, &modelSuziSmooth
	};
	for (int i = 0; i < 20; ++i) {
		int modelCount = static_cast<int>(models.size());
		int modelIndex = i % modelCount;
		Model* baseModel = models[modelIndex];

		int col = i % 5;
		int row = i / 5;
		float step = 1.5f;
		float centerShift = 3.0f;
		float x = col * step - centerShift;
		float y = 0.0f;
		float z = row * step - centerShift;

		int scaleIndex = i % 4;
		float scaleVal = 0.3f + 0.1f * scaleIndex;

		float angleYdeg = i * 20.0f;

		auto T = new CombinedTransformation();
		T->addTransformation(new Translation(glm::vec3(x, y, z)));
		T->addTransformation(new Scale(glm::vec3(scaleVal)));
		T->addTransformation(new Rotation(angleYdeg, 0.0f, 1.0f, 0.0f));

		auto obj = new SceneObject(
			baseModel,
			&shaderProgram,
			T
		);

		scene3->addObject(obj);
	}

	Scene* scene4 = new Scene();
	CombinedTransformation* trans = new CombinedTransformation();
	trans->addTransformation(new Translation(glm::vec3(-0.3f, -0.9f, 0.0f)));
	trans->addTransformation(new Scale(glm::vec3(0.4f)));

	SceneObject* treeObject = new SceneObject(
		&modelTree,
		&shaderProgram,
		trans		
	);
	scene4->addObject(treeObject);
	
	scenes.push_back(scene1);
	scenes.push_back(scene2);
	scenes.push_back(scene3);
	scenes.push_back(scene4);


	glEnable(GL_DEPTH_TEST);
	glViewport(0, 0, width, height);
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	return true;
}



void Application::mainLoop()
{
		Camera camera(glm::vec3(0.0f, 0.0f, 0.3f),
			glm::vec3(0.0f, 0.0f, 0.0f),
			glm::vec3(0.0f, 1.0f, 0.0f));

		float cameraSpeed = 0.05f;
		double lastX = 0.0, lastY = 0.0;
		bool firstMouse = true;

	while (!glfwWindowShouldClose(window))
	{
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		if (glfwGetKey(window, GLFW_KEY_1) == GLFW_PRESS) currentSceneIndex = 0;
		if (glfwGetKey(window, GLFW_KEY_2) == GLFW_PRESS) currentSceneIndex = 1;
		if (glfwGetKey(window, GLFW_KEY_3) == GLFW_PRESS) currentSceneIndex = 2;
		if (glfwGetKey(window, GLFW_KEY_4) == GLFW_PRESS) currentSceneIndex = 3;

		float t = static_cast<float>(glfwGetTime());
		

		// ======== ���������� ������� ========

		// ������� WSAD
		if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) camera.moveForward(cameraSpeed);
		if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) camera.moveBackward(cameraSpeed);
		if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) camera.moveLeft(cameraSpeed);
		if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) camera.moveRight(cameraSpeed);

		// ����: ������ ������ + �������� = ������� �����/������
		if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_RIGHT) == GLFW_PRESS)
		{
			double xpos, ypos;
			glfwGetCursorPos(window, &xpos, &ypos);

			if (firstMouse) { lastX = xpos; lastY = ypos; firstMouse = false; }

			float xoffset = static_cast<float>(xpos - lastX);
			lastX = xpos; lastY = ypos;

			float sensitivity = 0.002f; // ����� �������/���������
			glm::mat4 R = glm::rotate(glm::mat4(1.0f), -xoffset * sensitivity, glm::vec3(0.0f, 1.0f, 0.0f));

			glm::vec4 dir = glm::vec4(camera.getCenter() - camera.getEye(), 1.0f);
			dir = R * dir;

			camera.setCenter(camera.getEye() + glm::vec3(dir));
		}
		else
		{
			// ��������� ������ � ������ "�������" ���� ��� ��������� �������
			firstMouse = true;
		}

		// ======== ������� �� ������ (������ ����� ����������) ========
		glm::mat4 V = camera.getViewMatrix();
		glm::mat4 P = camera.getProjectionMatix(width, height);


		Scene* scene2 = scenes[1];

		auto dynamicRotation = new Rotation(t * 60.0f, 1.0f, 1.0f, 0.0f);
		auto t2 = new CombinedTransformation();
		t2->addTransformation(dynamicRotation);
		t2->addTransformation(new Translation(glm::vec3(0.0f, 0.0f, 0.0f)));
		scene2->getObject(0)->setTransformation(t2);
		if (SceneObject* o = scenes[1]->getObject(0)) {
			o->setTransformation(t2);
		}

		
		scenes[currentSceneIndex]->draw(P, V);

		glfwSwapBuffers(window);
		glfwPollEvents();
	}
}
void Application::cleanup()
{
	for (auto scene : scenes) {
		scene->clear();
		delete scene;
	}
	if (window) {
		glfwDestroyWindow(window);
		window = nullptr;
	}
	glfwTerminate();
}


