#pragma once
#include <GL/glew.h>
#include <string>

class ShaderProgram;

class Shader
{
	friend class ShaderProgram;
public:
	Shader(GLenum type);
	~Shader();

	bool compileFromFile(const std::string& path);
private:
	GLuint id;
	GLenum type;
};

