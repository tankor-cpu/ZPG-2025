#include "Shader.h"
#include <fstream>
#include <sstream>
#include <iostream>

Shader::Shader(GLenum type) : type(type)
{
	id = glCreateShader(type);
}

Shader::~Shader()
{
	if (id) {
		glDeleteShader(id);
	}
}

bool Shader::compileFromFile(const std::string& path)
{
	std::ifstream file(path);
	if (!file) {
		std::cerr << "Failed to open shader: " << path << std::endl;
		return false;
	}

	std::stringstream buf;
	buf << file.rdbuf();
	std::string src = buf.str();
	const char* srcPtr = src.c_str();

	glShaderSource(id, 1, &srcPtr, nullptr);
	glCompileShader(id);

	GLint ok = GL_FALSE;
	glGetShaderiv(id, GL_COMPILE_STATUS, &ok);
	if (!ok) {
		char log[1024];
		glGetShaderInfoLog(id, 1024, nullptr, log);
		std::cerr << "Shader compile error in " << path << ":\n" << log << std::endl;
		return false;
	}

	return true;
}
