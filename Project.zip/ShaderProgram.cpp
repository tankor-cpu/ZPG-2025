#include <iostream>
#include "ShaderProgram.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <string>



ShaderProgram::ShaderProgram(){
	id = glCreateProgram();
}

ShaderProgram::~ShaderProgram()
{
	if (id != 0) glDeleteProgram(id);
}

void ShaderProgram::use() const
{
	glUseProgram(id);
}

bool ShaderProgram::attachShader(Shader& shader)
{
	glAttachShader(id, shader.id);
	return true;
}

bool ShaderProgram::link()
{
	glLinkProgram(id);

	GLint ok = GL_FALSE;
	glGetProgramiv(id, GL_LINK_STATUS, &ok);
	if (!ok) {
		char log[1024];
		glGetProgramInfoLog(id, 1024, nullptr, log);
		std::cerr << "Program link error:\n" << log << std::endl;
		return false;
	}
	return true;
}



void ShaderProgram::setUniform(const std::string& name, const glm::mat4& matrix)
{
	GLint location = glGetUniformLocation(this->id, name.c_str());

	if (location == -1) {
		std::cerr << "Warning: uniform '" << name << "' not found in shader!\n";
		return;	
	}
	glUniformMatrix4fv(location, 1, GL_FALSE, glm::value_ptr(matrix));
}

void ShaderProgram::setUniform(const std::string& name, const glm::vec3& value)
{
	GLint location = glGetUniformLocation(this->id, name.c_str());

	if (location == -1) {
		std::cerr << "Warning: uniform '" << name << "' not found in shader!\n";
		return;
	}
	glUniform3fv(location, 1, glm::value_ptr(value));
}

void ShaderProgram::setUniform(const std::string& name, float value)
{
	GLint location = glGetUniformLocation(this->id, name.c_str());

	if (location == -1) {
		std::cerr << "Warning: uniform '" << name << "' not found in shader!\n";
		return;
	}
	glUniform1f(location, value);
}

void ShaderProgram::setUniform(const std::string& name, int value)
{
	GLint location = glGetUniformLocation(this->id, name.c_str());

	if (location == -1) {
		std::cerr << "Warning: uniform '" << name << "' not found in shader!\n";
		return;
	}
	glUniform1i(location, value);

}

void ShaderProgram::setUniform(const std::string& name, bool value)
{
	GLint location = glGetUniformLocation(this->id, name.c_str());

	if (location == -1) {
		std::cerr << "Warning: uniform '" << name << "' not found in shader!\n";
		return;
	}
	glUniform1i(location, value ? 1 : 0);
}


//glattachshader spojit s shader